#!/usr/bin/env bash
npx ts-node src/bin.ts $@